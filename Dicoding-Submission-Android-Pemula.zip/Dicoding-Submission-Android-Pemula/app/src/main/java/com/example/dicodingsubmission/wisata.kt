package com.example.dicodingsubmission

data class wisata (
    var nama: String = "",
    var rating: String = "",
    var photowebsite: String = "",
    var caption: String = "",
    var deskripsi: String = ""
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

)